import requests
import os
import json as jsn
import time
from datetime import datetime as dt
# cwd = os.path.dirname(os.path.realpath(__file__)) + '\\config.json'

def main():
    DIRECTORY = __file__.replace('main.py','config.json')
    filename=open(DIRECTORY,'r')
    load_json = jsn.load(filename)
    data = {
        'username': load_json['username'],
        'avatar_url': load_json['avatar_url'],
        'content': load_json['message'],
    }
    result = requests.post(load_json['url'], json=data)
    try:
        if load_json['loop'] == "":
            print("ERR: Please ")
        elif load_json['loop'] == "True":
            while True:
                time.sleep(1)
                print(result)
        elif load_json['loop'] == "False":
            print(result)
        elif load_json['loop'] != "True" or "False":
            print('ERR: Please insert "True" or "False" in the loop category of "config.json"')
    except TypeError:
        print('Please insert valid "True" or "False" statement inside of the "loop" section of "config.json"')

    with open(os.path.dirname(os.path.realpath(__file__)) + '\\logs.txt', 'w') as log:
            log.write(str(dt.now())+': ' + '<Response' + '['+str(result.status_code)+']>')

if __name__ == "__main__":
    main()